class Stack:
    def __init__(self):
        self.items = []

    def empty(self):
        return self.items == []

    def put(self, item):
        self.items.append(item)

    def get(self):
        return self.items.pop()


def mc_bfs(n,parent):
    q=Stack()
    vis=[]
    a=0
    b=0
    q.put((n,n,'L',a,b))
    parent[(n,n,'L',a,b)]=(-1,-1,'N',-1,-1)
    while not q.empty():

        x=q.get()
        vis.append(x)

        if x[0]==0 and x[1]==0 and x[2]=='R' and x[3]==n and x[4]==n:

            break
        if x[2]=='L':
            m=x[0]
            c=x[1]
            if(m-1>=0):
                lm=m-1
                lc=c
                rc=x[4]
                rm=x[3]+1
                qq=(lm,lc,'R',rm,rc)
                if (lc <= lm or lm == 0) and (rc <= rm or rm == 0):
                    if vis.__contains__(qq)==False:
                        parent[qq]=x
                        q.put(qq)
                        vis.append(qq)
            if c-1>=0:
                lm = m
                lc = c-1
                rc = x[4]+1
                rm = x[3]
                qq = (lm, lc, 'R', rm, rc)
                if (lc <= lm or lm == 0) and (rc <= rm or rm == 0):
                    if vis.__contains__(qq) == False:
                        parent[qq] = x
                        q.put(qq)
                        vis.append(qq)
            if m-1>=0 and c-1>=0:
                lm = m-1
                lc = c - 1
                rc = x[4]+1
                rm = x[3]+1
                qq = (lm, lc, 'R', rm, rc)
                if (lc <= lm or lm == 0) and (rc <= rm or rm == 0):

                    if vis.__contains__(qq) == False:
                        parent[qq] = x
                        q.put(qq)
                        vis.append(qq)
            if m-2>=0:
                lm = m-2
                lc = c
                rc = x[4]
                rm = x[3]+2
                qq = (lm, lc, 'R', rm, rc)
                if (lc <= lm or lm == 0) and (rc <= rm or rm == 0):
                    if vis.__contains__(qq) == False:
                        parent[qq] = x
                        q.put(qq)
                        vis.append(qq)
            if c-2>=0:
                lm = m
                lc = c - 2
                rc = x[4]+2
                rm = x[3]
                qq = (lm, lc, 'R', rm, rc)
                if (lc <= lm or lm == 0) and (rc <= rm or rm == 0):
                    if vis.__contains__(qq) == False:
                        parent[qq] = x
                        q.put(qq)
                        vis.append(qq)

        elif x[2] == 'R':
            m = x[3]
            c = x[4]

            if m - 1 >= 0:
                lm = x[0]+1
                lc = x[1]
                rc = x[4]
                rm = x[3]-1
                qq = (lm, lc, 'L',rm,rc)
                #print(qq)

                if (lc <=lm or lm==0) and (rc<=rm or rm==0):

                    if vis.__contains__(qq) == False:
                        parent[qq] = x
                        q.put(qq)
                        #print(qq)
                        vis.append(qq)
            if c - 1 >= 0:
                lm = x[0]
                lc = x[1]+1
                rc = x[4]-1
                rm = x[3]
                qq = (lm, lc, 'L',rm,rc)

                if (lc <= lm or lm == 0) and (rc <= rm or rm == 0):
                    if vis.__contains__(qq) == False:
                        parent[qq] = x
                        q.put(qq)
                        #print(qq)
                        vis.append(qq)

            if m - 2 >= 0:
                lm = x[0]+2
                lc = x[1]
                rc = x[4]
                rm = x[3]-2
                qq = (lm, lc, 'L',rm,rc)
                if (lc <= lm or lm == 0) and (rc <= rm or rm == 0):
                    if vis.__contains__(qq) == False:
                        parent[qq] = x
                        q.put(qq)
                        #print(qq)
                        vis.append(qq)
            if c - 2 >= 0:
                lm = x[0]
                lc = x[1]+2
                rc = x[4]-2
                rm = x[3]
                qq = (lm, lc, 'L',rm,rc)
                if (lc <= lm or lm == 0) and (rc <= rm or rm == 0):
                    if vis.__contains__(qq) == False:
                        parent[qq] = x
                        q.put(qq)
                        #print(qq)
                        vis.append(qq)

            if c - 1 >= 0 and m-1>=0:
                lm = x[0]+1
                lc = x[1]+1
                rc = x[4]-1
                rm = x[3]-1
                qq = (lm, lc, 'L',rm,rc)
                if (lc <= lm or lm == 0) and (rc <= rm or rm == 0):
                    if vis.__contains__(qq) == False:
                        parent[qq] = x
                        q.put(qq)
                        #print(qq)
                        vis.append(qq)

def printt(fin,parent):
    if fin not in parent:
        return
    else :
        printt(parent[fin],parent)
        print(fin)

n=input()
n=int(n)
parent={}
fin=(0,0,'R',3,3)


mc_bfs(n,parent)
printt(fin,parent)